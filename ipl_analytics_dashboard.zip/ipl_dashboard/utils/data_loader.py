# utils/data_loader.py
# ------------------------------------------------------------------
# Handles loading, cleaning, and preprocessing of IPL datasets
# ------------------------------------------------------------------

import pandas as pd
import numpy as np


# ── Team name standardisation map ─────────────────────────────────
TEAM_NAME_MAP = {
    "Delhi Daredevils":             "Delhi Capitals",
    "Deccan Chargers":              "Sunrisers Hyderabad",
    "Pune Warriors":                "Rising Pune Supergiant",
    "Rising Pune Supergiants":      "Rising Pune Supergiant",
    "Kings XI Punjab":              "Punjab Kings",
}


def load_matches(path: str = "datasets/matches.csv") -> pd.DataFrame:
    """
    Load and clean the matches dataset.

    Steps:
      1. Read CSV
      2. Drop duplicate rows
      3. Fill missing 'player_of_match' with 'Unknown'
      4. Standardise team names
    """
    df = pd.read_csv(path)

    # Remove exact duplicate rows
    df.drop_duplicates(inplace=True)

    # Fill common missing columns
    df["player_of_match"] = df["player_of_match"].fillna("Unknown")
    df["winner"]          = df["winner"].fillna("No Result")
    df["city"]            = df["city"].fillna("Unknown")
    df["umpire1"]         = df.get("umpire1", pd.Series(dtype=str)).fillna("Unknown")
    df["umpire2"]         = df.get("umpire2", pd.Series(dtype=str)).fillna("Unknown")

    # Standardise team names across several columns
    for col in ["team1", "team2", "winner", "toss_winner"]:
        if col in df.columns:
            df[col] = df[col].replace(TEAM_NAME_MAP)

    # Parse season as integer if possible
    if "season" in df.columns:
        df["season"] = pd.to_numeric(df["season"], errors="coerce")

    return df


def load_deliveries(path: str = "datasets/deliveries.csv") -> pd.DataFrame:
    """
    Load and clean the deliveries dataset.

    Steps:
      1. Read CSV
      2. Drop duplicates
      3. Fill missing numeric columns with 0
      4. Standardise batting / bowling team names
    """
    df = pd.read_csv(path)

    df.drop_duplicates(inplace=True)

    # Numeric columns that might have NaN
    numeric_cols = [
        "batsman_runs", "extra_runs", "total_runs",
        "player_dismissed", "is_wicket",
    ]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    # Standardise team names
    for col in ["batting_team", "bowling_team"]:
        if col in df.columns:
            df[col] = df[col].replace(TEAM_NAME_MAP)

    return df


def merge_datasets(matches: pd.DataFrame,
                   deliveries: pd.DataFrame) -> pd.DataFrame:
    """
    Merge deliveries with match-level info (season, venue, city).
    Useful for season-wise or venue-wise delivery analysis.
    """
    match_meta = matches[["id", "season", "venue", "city"]].rename(
        columns={"id": "match_id"}
    )
    merged = deliveries.merge(match_meta, on="match_id", how="left")
    return merged
