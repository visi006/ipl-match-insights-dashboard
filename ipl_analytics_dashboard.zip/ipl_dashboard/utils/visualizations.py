# utils/visualizations.py
# ------------------------------------------------------------------
# Reusable Matplotlib / Seaborn chart functions
# Each function returns a matplotlib Figure so Streamlit can render it
# ------------------------------------------------------------------

import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
import pandas as pd
import numpy as np

# ── Global Style ──────────────────────────────────────────────────
IPL_COLORS = [
    "#E8871E", "#1B4F72", "#2ECC71", "#E74C3C",
    "#8E44AD", "#F39C12", "#1ABC9C", "#C0392B",
    "#2980B9", "#D35400",
]
sns.set_theme(style="darkgrid", palette=IPL_COLORS)
plt.rcParams.update({
    "figure.facecolor": "#0D1117",
    "axes.facecolor":   "#161B22",
    "axes.labelcolor":  "#C9D1D9",
    "xtick.color":      "#C9D1D9",
    "ytick.color":      "#C9D1D9",
    "text.color":       "#C9D1D9",
    "grid.color":       "#21262D",
    "axes.titlecolor":  "#F0F6FC",
    "axes.titlesize":   14,
    "axes.titleweight": "bold",
})


def _save_and_return(fig: plt.Figure) -> plt.Figure:
    """Tighten layout and return figure."""
    fig.tight_layout()
    return fig


# ── 1. Matches Won – Horizontal Bar Chart ─────────────────────────
def plot_matches_won(wins: pd.Series) -> plt.Figure:
    """Horizontal bar chart of matches won by each team."""
    fig, ax = plt.subplots(figsize=(10, 6))
    bars = ax.barh(wins.index[::-1], wins.values[::-1],
                   color=IPL_COLORS[:len(wins)], edgecolor="none")
    ax.set_xlabel("Matches Won")
    ax.set_title("🏆 Total IPL Matches Won by Each Team")
    for bar in bars:
        ax.text(bar.get_width() + 0.5, bar.get_y() + bar.get_height() / 2,
                f"{int(bar.get_width())}", va="center", fontsize=9, color="#C9D1D9")
    return _save_and_return(fig)


# ── 2. Toss Impact – Pie Chart ────────────────────────────────────
def plot_toss_impact(toss_df: pd.DataFrame) -> plt.Figure:
    """Pie chart showing whether toss winner also wins the match."""
    fig, ax = plt.subplots(figsize=(6, 6))
    labels = ["Toss ≠ Match Winner", "Toss = Match Winner"]
    vals   = toss_df.sort_values("Toss Winner Won Match")["Count"].values
    ax.pie(vals, labels=labels, autopct="%1.1f%%",
           colors=["#E74C3C", "#2ECC71"],
           startangle=140, wedgeprops={"edgecolor": "#0D1117", "linewidth": 2})
    ax.set_title("🎯 Does Toss Winner Win the Match?")
    return _save_and_return(fig)


# ── 3. Top Run Scorers – Bar Chart ────────────────────────────────
def plot_top_run_scorers(run_df: pd.DataFrame) -> plt.Figure:
    """Vertical bar chart of top 10 run scorers."""
    fig, ax = plt.subplots(figsize=(12, 6))
    bars = ax.bar(run_df["Player"], run_df["Total Runs"],
                  color=IPL_COLORS[:len(run_df)], edgecolor="none")
    ax.set_xlabel("Player")
    ax.set_ylabel("Total Runs")
    ax.set_title("🏏 Top 10 IPL Run Scorers (All Time)")
    plt.xticks(rotation=30, ha="right")
    for bar in bars:
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 30,
                f"{int(bar.get_height())}", ha="center", fontsize=8, color="#C9D1D9")
    return _save_and_return(fig)


# ── 4. Top Wicket Takers – Bar Chart ─────────────────────────────
def plot_top_wicket_takers(wkt_df: pd.DataFrame) -> plt.Figure:
    """Vertical bar chart of top 10 wicket takers."""
    fig, ax = plt.subplots(figsize=(12, 6))
    bars = ax.bar(wkt_df["Player"], wkt_df["Wickets"],
                  color=["#8E44AD"] * len(wkt_df), edgecolor="none")
    ax.set_xlabel("Player")
    ax.set_ylabel("Wickets")
    ax.set_title("🎳 Top 10 IPL Wicket Takers (All Time)")
    plt.xticks(rotation=30, ha="right")
    for bar in bars:
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.3,
                f"{int(bar.get_height())}", ha="center", fontsize=9, color="#C9D1D9")
    return _save_and_return(fig)


# ── 5. Team Win Percentage – Bar Chart ───────────────────────────
def plot_team_win_pct(stats_df: pd.DataFrame) -> plt.Figure:
    """Bar chart of win % per team (≥10 matches played)."""
    fig, ax = plt.subplots(figsize=(12, 6))
    colors = [IPL_COLORS[i % len(IPL_COLORS)] for i in range(len(stats_df))]
    ax.bar(stats_df["Team"], stats_df["Win %"], color=colors, edgecolor="none")
    ax.set_xlabel("Team")
    ax.set_ylabel("Win %")
    ax.set_title("📊 IPL Team Win Percentage")
    ax.yaxis.set_major_formatter(mticker.PercentFormatter())
    plt.xticks(rotation=35, ha="right")
    return _save_and_return(fig)


# ── 6. Highest Scoring Venues – Horizontal Bar ───────────────────
def plot_venues(venue_df: pd.DataFrame) -> plt.Figure:
    """Horizontal bar chart of average runs per match at top venues."""
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.barh(venue_df["Venue"][::-1], venue_df["Avg Runs per Match"][::-1],
            color="#F39C12", edgecolor="none")
    ax.set_xlabel("Average Runs per Match")
    ax.set_title("🏟️ Highest Scoring IPL Venues")
    return _save_and_return(fig)


# ── 7. Season-wise Avg Score – Line Graph ────────────────────────
def plot_season_avg_score(season_df: pd.DataFrame) -> plt.Figure:
    """Line graph showing average match score across IPL seasons."""
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(season_df["season"], season_df["Avg Score"],
            marker="o", linewidth=2.5, color="#E8871E", markersize=8,
            markerfacecolor="#F39C12", markeredgecolor="#0D1117")
    ax.fill_between(season_df["season"], season_df["Avg Score"],
                    alpha=0.15, color="#E8871E")
    ax.set_xlabel("Season")
    ax.set_ylabel("Average Total Score")
    ax.set_title("📈 Season-wise Average Match Score Trend")
    ax.xaxis.set_major_locator(mticker.MaxNLocator(integer=True))
    return _save_and_return(fig)


# ── 8. Strike Rate – Scatter Plot ────────────────────────────────
def plot_strike_rate(sr_df: pd.DataFrame, top_n: int = 20) -> plt.Figure:
    """Scatter plot of Runs vs Strike Rate for top batsmen."""
    df = sr_df.head(top_n)
    fig, ax = plt.subplots(figsize=(10, 6))
    scatter = ax.scatter(df["Runs"], df["Strike Rate"],
                         c=df["Strike Rate"], cmap="YlOrRd",
                         s=120, edgecolors="#0D1117", linewidths=0.5, zorder=3)
    for _, row in df.iterrows():
        ax.annotate(row["Player"], (row["Runs"], row["Strike Rate"]),
                    textcoords="offset points", xytext=(5, 4),
                    fontsize=7, color="#C9D1D9")
    plt.colorbar(scatter, ax=ax, label="Strike Rate")
    ax.set_xlabel("Career Runs")
    ax.set_ylabel("Strike Rate")
    ax.set_title("⚡ Runs vs Strike Rate (Top Batsmen)")
    return _save_and_return(fig)


# ── 9. Orange Cap Table Visual ───────────────────────────────────
def plot_orange_cap(oc_df: pd.DataFrame) -> plt.Figure:
    """Horizontal bar chart of Orange Cap winners per season."""
    fig, ax = plt.subplots(figsize=(10, max(6, len(oc_df) * 0.5)))
    y_pos = range(len(oc_df))
    bars  = ax.barh(y_pos, oc_df["Runs"], color="#E8871E", edgecolor="none")
    ax.set_yticks(list(y_pos))
    ax.set_yticklabels([f"{int(r['season'])} – {r['Player']}" for _, r in oc_df.iterrows()])
    ax.set_xlabel("Runs")
    ax.set_title("🟠 Orange Cap Winners (Most Runs per Season)")
    for bar, val in zip(bars, oc_df["Runs"]):
        ax.text(bar.get_width() + 5, bar.get_y() + bar.get_height() / 2,
                str(int(val)), va="center", fontsize=8, color="#C9D1D9")
    return _save_and_return(fig)


# ── 10. Purple Cap Table Visual ──────────────────────────────────
def plot_purple_cap(pc_df: pd.DataFrame) -> plt.Figure:
    """Horizontal bar chart of Purple Cap winners per season."""
    fig, ax = plt.subplots(figsize=(10, max(6, len(pc_df) * 0.5)))
    y_pos = range(len(pc_df))
    bars  = ax.barh(y_pos, pc_df["Wickets"], color="#8E44AD", edgecolor="none")
    ax.set_yticks(list(y_pos))
    ax.set_yticklabels([f"{int(r['season'])} – {r['Player']}" for _, r in pc_df.iterrows()])
    ax.set_xlabel("Wickets")
    ax.set_title("🟣 Purple Cap Winners (Most Wickets per Season)")
    for bar, val in zip(bars, pc_df["Wickets"]):
        ax.text(bar.get_width() + 0.1, bar.get_y() + bar.get_height() / 2,
                str(int(val)), va="center", fontsize=8, color="#C9D1D9")
    return _save_and_return(fig)


# ── 11. Dismissal Heatmap ─────────────────────────────────────────
def plot_dismissal_heatmap(deliveries: pd.DataFrame) -> plt.Figure:
    """
    Heatmap: bowling team × dismissal type (count of wickets).
    Shows which teams take wickets in which ways.
    """
    wickets = deliveries[deliveries["is_wicket"] == 1].copy()
    heat    = wickets.pivot_table(
        index="bowling_team", columns="dismissal_kind",
        values="is_wicket", aggfunc="count", fill_value=0
    )
    fig, ax = plt.subplots(figsize=(14, 8))
    sns.heatmap(heat, annot=True, fmt="d", cmap="YlOrRd",
                linewidths=0.5, linecolor="#0D1117",
                ax=ax, cbar_kws={"label": "Wickets"})
    ax.set_title("🔥 Dismissal Type Heatmap by Bowling Team")
    ax.set_xlabel("Dismissal Type")
    ax.set_ylabel("Bowling Team")
    plt.xticks(rotation=30, ha="right")
    return _save_and_return(fig)
