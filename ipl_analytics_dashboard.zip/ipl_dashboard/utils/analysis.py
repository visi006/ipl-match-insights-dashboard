# utils/analysis.py
# ------------------------------------------------------------------
# All Exploratory Data Analysis (EDA) functions for the IPL Dashboard
# Each function takes cleaned DataFrames and returns a summary DataFrame
# ------------------------------------------------------------------

import pandas as pd
import numpy as np


# ── 1. Matches Won by Each Team ────────────────────────────────────
def matches_won_by_team(matches: pd.DataFrame) -> pd.Series:
    """Count total IPL matches won by each team (excluding No Result)."""
    won = matches[matches["winner"] != "No Result"]["winner"]
    return won.value_counts()


# ── 2. Toss Impact Analysis ────────────────────────────────────────
def toss_impact(matches: pd.DataFrame) -> pd.DataFrame:
    """
    Check how often the toss winner also wins the match.
    Returns a small summary DataFrame with counts and percentage.
    """
    df = matches.copy()
    df["toss_win_match_win"] = df["toss_winner"] == df["winner"]
    summary = df["toss_win_match_win"].value_counts().reset_index()
    summary.columns = ["Toss Winner Won Match", "Count"]
    summary["Percentage"] = (summary["Count"] / summary["Count"].sum() * 100).round(2)
    return summary


def toss_decision_impact(matches: pd.DataFrame) -> pd.DataFrame:
    """Win rate by toss decision (bat / field)."""
    df = matches.copy()
    df["toss_won_match"] = df["toss_winner"] == df["winner"]
    return (
        df.groupby("toss_decision")["toss_won_match"]
        .mean()
        .mul(100)
        .round(2)
        .reset_index()
        .rename(columns={"toss_won_match": "Win %"})
    )


# ── 3. Top Run Scorers ─────────────────────────────────────────────
def top_run_scorers(deliveries: pd.DataFrame, top_n: int = 10) -> pd.DataFrame:
    """Return the top N run scorers across all IPL seasons."""
    runs = (
        deliveries.groupby("batsman")["batsman_runs"]
        .sum()
        .sort_values(ascending=False)
        .head(top_n)
        .reset_index()
    )
    runs.columns = ["Player", "Total Runs"]
    return runs


# ── 4. Top Wicket Takers ───────────────────────────────────────────
def top_wicket_takers(deliveries: pd.DataFrame, top_n: int = 10) -> pd.DataFrame:
    """
    Return the top N wicket takers.
    Excludes run-outs (dismissal_kind == 'run out') as they are not
    credited to the bowler.
    """
    wickets = deliveries[
        (deliveries["is_wicket"] == 1) &
        (deliveries["dismissal_kind"] != "run out")
    ]
    wkt_count = (
        wickets.groupby("bowler")["is_wicket"]
        .count()
        .sort_values(ascending=False)
        .head(top_n)
        .reset_index()
    )
    wkt_count.columns = ["Player", "Wickets"]
    return wkt_count


# ── 5. Most Successful Teams (Win %) ──────────────────────────────
def team_win_percentage(matches: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate win percentage for every team that has played ≥ 10 matches.
    """
    played = pd.concat([matches["team1"], matches["team2"]]).value_counts()
    won    = matches_won_by_team(matches)

    stats = pd.DataFrame({"Played": played, "Won": won}).fillna(0)
    stats["Win %"] = (stats["Won"] / stats["Played"] * 100).round(2)
    stats = stats[stats["Played"] >= 10].sort_values("Win %", ascending=False)
    stats.index.name = "Team"
    return stats.reset_index()


# ── 6. Highest Scoring Venues ─────────────────────────────────────
def highest_scoring_venues(deliveries: pd.DataFrame,
                            matches: pd.DataFrame,
                            top_n: int = 10) -> pd.DataFrame:
    """Average total runs per match at each venue."""
    # Total runs per match
    runs_per_match = deliveries.groupby("match_id")["total_runs"].sum().reset_index()
    runs_per_match.columns = ["match_id", "total_runs"]

    # Attach venue
    venue_map = matches[["id", "venue"]].rename(columns={"id": "match_id"})
    merged = runs_per_match.merge(venue_map, on="match_id")

    venue_avg = (
        merged.groupby("venue")["total_runs"]
        .mean()
        .sort_values(ascending=False)
        .head(top_n)
        .round(1)
        .reset_index()
    )
    venue_avg.columns = ["Venue", "Avg Runs per Match"]
    return venue_avg


# ── 7. Season-wise Trends ─────────────────────────────────────────
def season_wise_trends(matches: pd.DataFrame) -> pd.DataFrame:
    """Total matches and unique teams per IPL season."""
    trends = (
        matches.groupby("season")
        .agg(
            Total_Matches=("id", "count"),
            Teams=("team1", lambda x: pd.concat([x, matches.loc[x.index, "team2"]]).nunique()),
        )
        .reset_index()
    )
    return trends


def season_avg_score(deliveries: pd.DataFrame,
                     matches: pd.DataFrame) -> pd.DataFrame:
    """Average total score per match, season-wise."""
    runs_per_match = deliveries.groupby("match_id")["total_runs"].sum().reset_index()
    meta = matches[["id", "season"]].rename(columns={"id": "match_id"})
    merged = runs_per_match.merge(meta, on="match_id")
    return (
        merged.groupby("season")["total_runs"]
        .mean()
        .round(1)
        .reset_index()
        .rename(columns={"total_runs": "Avg Score"})
    )


# ── 8. Player Strike Rate ──────────────────────────────────────────
def player_strike_rate(deliveries: pd.DataFrame,
                        min_runs: int = 500) -> pd.DataFrame:
    """
    Strike rate = (runs scored / balls faced) × 100
    Only includes players with at least `min_runs` runs.
    """
    # Balls faced: exclude wides (wide_runs > 0) — batsman doesn't face wides
    balls = deliveries[deliveries.get("wide_runs", pd.Series(0, index=deliveries.index)) == 0]
    balls_faced = balls.groupby("batsman")["batsman_runs"].count().rename("Balls")
    total_runs  = deliveries.groupby("batsman")["batsman_runs"].sum().rename("Runs")

    sr_df = pd.concat([total_runs, balls_faced], axis=1).dropna()
    sr_df = sr_df[sr_df["Runs"] >= min_runs].copy()
    sr_df["Strike Rate"] = (sr_df["Runs"] / sr_df["Balls"] * 100).round(2)
    sr_df = sr_df.sort_values("Strike Rate", ascending=False).reset_index()
    sr_df.rename(columns={"batsman": "Player"}, inplace=True)
    return sr_df[["Player", "Runs", "Balls", "Strike Rate"]]


# ── 9. Orange Cap (Most Runs per Season) ──────────────────────────
def orange_cap(deliveries: pd.DataFrame,
               matches: pd.DataFrame) -> pd.DataFrame:
    """Top run scorer for each IPL season (Orange Cap winners)."""
    meta = matches[["id", "season"]].rename(columns={"id": "match_id"})
    merged = deliveries.merge(meta, on="match_id")
    season_runs = (
        merged.groupby(["season", "batsman"])["batsman_runs"]
        .sum()
        .reset_index()
    )
    idx = season_runs.groupby("season")["batsman_runs"].idxmax()
    cap = season_runs.loc[idx].rename(columns={"batsman": "Player", "batsman_runs": "Runs"})
    return cap.sort_values("season").reset_index(drop=True)


# ── 10. Purple Cap (Most Wickets per Season) ──────────────────────
def purple_cap(deliveries: pd.DataFrame,
               matches: pd.DataFrame) -> pd.DataFrame:
    """Top wicket taker for each IPL season (Purple Cap winners)."""
    meta = matches[["id", "season"]].rename(columns={"id": "match_id"})
    wickets = deliveries[
        (deliveries["is_wicket"] == 1) &
        (deliveries["dismissal_kind"] != "run out")
    ].copy()
    merged = wickets.merge(meta, on="match_id")
    season_wkts = (
        merged.groupby(["season", "bowler"])["is_wicket"]
        .count()
        .reset_index()
    )
    idx = season_wkts.groupby("season")["is_wicket"].idxmax()
    cap = season_wkts.loc[idx].rename(columns={"bowler": "Player", "is_wicket": "Wickets"})
    return cap.sort_values("season").reset_index(drop=True)


# ── 11. Player-level Batting Summary ──────────────────────────────
def player_batting_summary(deliveries: pd.DataFrame,
                            player: str) -> dict:
    """Return a quick batting stat dictionary for a given player."""
    pdf = deliveries[deliveries["batsman"] == player]
    if pdf.empty:
        return {}
    runs   = int(pdf["batsman_runs"].sum())
    balls  = int(pdf[pdf.get("wide_runs", pd.Series(0, index=pdf.index)) == 0].shape[0])
    fours  = int((pdf["batsman_runs"] == 4).sum())
    sixes  = int((pdf["batsman_runs"] == 6).sum())
    sr     = round(runs / balls * 100, 2) if balls > 0 else 0
    return {
        "Player": player, "Runs": runs, "Balls": balls,
        "4s": fours,      "6s": sixes,  "Strike Rate": sr,
    }


# ── 12. Team Head-to-Head ─────────────────────────────────────────
def head_to_head(matches: pd.DataFrame,
                 team1: str, team2: str) -> pd.DataFrame:
    """Win/loss record between two specific teams."""
    mask = (
        ((matches["team1"] == team1) & (matches["team2"] == team2)) |
        ((matches["team1"] == team2) & (matches["team2"] == team1))
    )
    h2h = matches[mask].copy()
    return h2h[["season", "date", "venue", "winner", "player_of_match"]]
